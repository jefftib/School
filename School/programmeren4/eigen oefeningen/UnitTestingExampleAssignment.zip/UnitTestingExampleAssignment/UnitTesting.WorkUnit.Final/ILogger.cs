﻿namespace UnitTesting.WorkUnit.Final
{
    public interface ILogger
    {
        void Log(string message);
    }
}