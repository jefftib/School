﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace EscapeFromTheWoods
{
    class Forest
    {
        private int Id;
        public  int maxWidth { get; set; }
        public int maxHeight { get; set; }
        public int TreesInforest = 100;
        public int monkeys = 3;
        Random _random = new Random();
       public List<Tree> treelist = new List<Tree>();
       public Forest(int maxWidth, int maxHeight) 
        {
         
            this.maxWidth = maxWidth;
            this.maxHeight = maxHeight;

        }
    public void GenerateTrees()
        {
            for (int i = 0; i < TreesInforest; i++)
            {
                Tree t = new Tree(1, _random.Next(0, maxWidth), _random.Next(0, maxHeight));
                if (treelist.Contains(t))
                {
                    i--;
                }
                else
                {
                    treelist.Add(t);
                }

            }

        }

    public void PlaceMonkey()
        {
            for (int i = 0; i < monkeys; i++)
            {
                for (int i2 = 0; i2 < treelist.Count; i2++)
                {
                    int RandomTree = _random.Next(treelist.Count);
                    Monkey m = new Monkey(1, "Brian", treelist[RandomTree]);
                }

            }

        }
    }
}
