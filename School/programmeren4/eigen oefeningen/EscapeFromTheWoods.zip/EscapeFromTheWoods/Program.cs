﻿using System;

namespace EscapeFromTheWoods
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            /*
             * TODO: give monkey and forest auto gen random id and name
             * TODO: fix jump
             * TODO: implement bitmap
             * TODO: implement database
             * TODO: save to db
             * TODO: implement async/treading 
             * 
             * 
             */
     
        }
    }
}
