﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EscapeFromTheWoods
{
    class Tree
    {
        public int x;
        public int y;
        public int id;
        public bool occupied = false;


        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            return obj is Tree && ((Tree)obj).x.Equals(this.x) && ((Tree)obj).y.Equals(this.y);

        }
     

        public Tree(int id, int x , int y)
        {
            this.id = id;
            this.x = x;
            this.y = y;
        }
        
    }
}
