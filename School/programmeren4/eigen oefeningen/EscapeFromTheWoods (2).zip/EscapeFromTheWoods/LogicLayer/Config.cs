﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogicLayer
{
    public static class Config
    {
        public static string StoragePath { get; set; } = @"../../../";
   
    }
}
